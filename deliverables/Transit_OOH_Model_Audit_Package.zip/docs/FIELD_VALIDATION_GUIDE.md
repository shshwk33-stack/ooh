# 독립 현장 검증 도구 사용법

이 도구는 **아직 수집하지 않은 현장 결과를 제공하지 않는다.** 실제 입력 모델과 현장 통과 계수를 비교할 수 있도록 사전 고정·기록·분석을 구현했다. 앱의 `독립 현장 검증` 화면 또는 CLI를 사용한다.

## 1. 점수를 보기 전에 관측 설계 검토

여러 도로 규모·상권 강도가 포함된 후보를 정하고, 후보 공간 단위와 관측 지점을 검토한다. 구역 평균 점수를 대표점 하나에 적용할 때의 대표성은 별도 연구 가정이다. 지도 중심이나 임의 좌표가 안전하고 적절한 관측 지점이라고 보장하지 않는다.

현재 도구는 최소 10개 후보·5개 날짜, 모든 지점의 같은 시작 시각·같은 1~120분 관측 시간을 요구하는 균형 설계다. 인력·장비를 준비할 수 없는 경우 표본을 임의로 채우지 말고 설계를 수정해야 한다. 임곗값은 최소 실행 조건이며 표본 수·검정력 산정 결과가 아니다. 계절·시각 일반화와 공간/날짜 상관을 해결하지 않는다.

관측 대상은 차량 직접 통과 또는 보행자 직접 통과 중 하나다. 둘을 합치지 않으며 광고 주목·회상·전환과 동일시하지 않는다. 현장 기록의 해상도·진행방향·차폐·기상·행사·공사 조건을 기록한다. 개인 얼굴·번호판 정보는 필요하지 않다.

## 2. 모델과 일정을 고정

점수 CSV의 필수 열은 다음과 같다. 실제 관측 지점과 자료를 준비한 후 채운다.

```csv
grid_id,longitude,latitude,static_score,mobility_score
```

A/B는 미리 고정된 0~1 점수이고 C는 선택 α로 계산한다. 정규화·특성 산식·후보군을 테스트 결과에 맞춰 다시 조정하지 않는다. 실자료 분류·마지막 입력 날짜·출처·입력 SHA256·공간 대응 검토·독립 수집 계획을 기록한다. 실제 통합 입력이 준비되지 않은 상태에서 합성 예제 점수를 실측 모델로 선언하지 않는다.

CLI 메타데이터는 아래 키를 실제 값으로 채운 JSON이다. 빈 예시를 그대로 제출하면 실행되지 않는다.

```json
{
  "spatial_support_id": "",
  "training_end_date": "",
  "prediction_source": "",
  "prediction_observation_type": "estimated",
  "input_sha256": "",
  "target": "manual_vehicle_passages",
  "site_mapping_review": "",
  "independence_plan": ""
}
```

앱은 업로드 점수 CSV의 SHA256을 자동 계산한다. CLI 사용자는 동일 파일의 해시를 입력한다. 과거 자료를 훈련으로 쓰더라도 관측 시점과 오래 떨어져 있으면 시간적 일반화 평가라는 제한을 보고해야 한다.

```bash
# 날짜는 고정 시각 이후의 실제 계획 날짜로 바꾼다.
bash scripts/run.sh transit-ooh field-freeze \
  --scores data/raw/reviewed_site_scores.csv \
  --metadata data/raw/campaign_metadata.json \
  --dates YYYY-MM-DD YYYY-MM-DD YYYY-MM-DD YYYY-MM-DD YYYY-MM-DD \
  --start-time 12:00 --duration 15 --weight .5 \
  --output data/processed/field_campaign.zip
```

ZIP에 `protocol.json`, `predictions.csv`, `schedule.csv`, `observations_BLIND.csv`, `README.txt`가 들어간다. **관측자에게는 `observations_BLIND.csv`만 전달**해 모델 점수로부터 가린다. ZIP은 소스·Git이 아닌 로컬 연구 자료로 관리한다. 기관에 제출하거나 외부 등록한 사전등록은 아니며 해시는 변경 검사 수단이다.

## 3. 실제 관측 기록

기록지의 `count`에 실제 계수를, `observer_id`에 가명 관측자 코드를, `conditions`에 날씨·행사 등 상황을 적는다. 실제 통과가 0회이면 0, 관측하지 못했다면 빈칸이다. 결측을 0으로 바꾸지 않는다.

여러 관측자가 같은 세션을 중복 측정했다면 일치도 확인용으로 별도 보존한다. 현재 평가표에는 사전에 정한 주 관측자 한 명의 행만 넣어 중복 계수를 피한다. 일정·시간·후보가 변경되면 기존 고정 조건을 조용히 덮어쓰지 않는다. 불완전한 캠페인은 현재 균형 분석기에서 평가를 중단한다.

## 4. 동결된 A/B/C 평가

```bash
bash scripts/run.sh transit-ooh field-evaluate \
  --campaign data/processed/field_campaign.zip \
  --observations data/raw/observations_BLIND.csv \
  --replicates 1000 --output data/processed/field_evaluation
```

- 고정 해시·날짜·관측 길이·후보 완전성·중복·음수·결측을 검사한다. 아직 끝나지 않은 미래 캠페인은 평가하지 않는다.
- 관측값을 시간당 통과 계수로 바꾸고 각 지점의 관측일 평균을 계산한다. 행 수를 독립 지점 수로 세지 않는다.
- 각 모델과 독립 계수의 Spearman을 계산한다. 사전에 정한 주 비교는 **C−A**, 보조 비교는 B−A·C−B다. 독립 점수가 없으면 정확도나 성능 향상값을 만들지 않는다.
- 같은 날짜를 모든 지점·모델에 함께 재표집하는 방식과, 지점·날짜를 각각 복원 추출하는 교차 방식으로 paired 차이를 계산한다. 교차 방식도 공간·시계열 상관이나 무작위 표집을 보장하지 않는다.
- Top-K의 독립 계수 회수 비율과 동점에 따른 최소·최대 범위를 표시한다. 이는 후보들에서 센 통과량의 비중이며 고유 인원이나 실제 광고 도달률이 아니다.
- 전체 점수나 관측 계수가 같은 경우 순위상관은 미정의다. 유효 재표집이 90% 미만이면 분위수 구간을 내지 않고 유효 반복수를 표시한다. 자동 유의성·성능 향상 판정이나 사후 가중치 최적화를 수행하지 않는다.

출력: 모델별 지표 CSV, paired 차이 CSV, 재표집 지점·날짜 인덱스, 지점별 독립 계수, SHA256/seed/제한 기록 JSON. 브라우저에서는 이를 ZIP으로 내려받는다. 파일 내용의 실제 독립성·현장 수집 여부는 사용자의 연구 관리로 확인해야 한다.
