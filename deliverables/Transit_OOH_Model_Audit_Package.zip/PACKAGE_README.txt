Transit OOH 모델 고도화 검수 패키지

먼저 docs/MODEL_AUDIT_REPORT.md를 읽으세요.
설치: bash scripts/setup.sh
앱: bash scripts/run.sh streamlit run app/streamlit_app.py
테스트: bash scripts/run.sh pytest

코드·설정·테스트·고정 의존성·합성 예제·새 연구 그림/표를 포함합니다.
기존 비교 검사의 입력인 원본 합성 PoC 노트북도 포함합니다.
기관 원본·개별 O/D·인증키·과거 전체 보고서·발표 원본은 포함하지 않습니다.
공식자료 화면은 별도 수집/입력 후 사용하고 자료가 없으면 입력 대기로 표시됩니다.
실제 통합 모델 우월성과 광고효과의 독립 실증은 미완료입니다.
README의 과거 보고서/발표 링크는 GitHub 전체 저장소에서 열 수 있습니다.
