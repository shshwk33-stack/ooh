Transit OOH 공개자료 연구·검수 패키지

연구: docs/PUBLIC_DATA_RESEARCH_REPORT.md
설치: bash scripts/setup.sh
앱: bash scripts/run.sh streamlit run app/streamlit_app.py
검사: bash scripts/run.sh pytest
독립 조합 재계산: bash scripts/run.sh python scripts/check_public_portfolios.py

실제 집계표로 새 후보선정 연구를 재현합니다. 기관 원본·개별 O/D·키는 포함하지 않습니다. 다른 실제 자료 화면은 별도 입력이 필요합니다. 과거 예비값 인지 후 회고적 재현이며 외부 사전등록·광고효과 검증이 아닙니다.

경진대회 제출용 파일: deliverables/competition2026/Transit_OOH_Competition_Anonymous.pdf
이 전체 검수 ZIP은 과거 코드·문서·합성 PoC도 포함합니다. 익명 심사에는 지정한 익명 PDF만 사용하세요. 별첨 서명과 팀 역할 사실 확인은 사용자가 마쳐야 합니다.
